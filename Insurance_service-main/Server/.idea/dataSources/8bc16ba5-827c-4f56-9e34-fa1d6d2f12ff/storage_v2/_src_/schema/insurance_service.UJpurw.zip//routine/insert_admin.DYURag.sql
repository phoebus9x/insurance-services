create
    definer = root@localhost procedure insert_admin(IN surname varchar(45), IN usname varchar(45), IN birthday date,
                                                    IN phone varchar(13), IN address varchar(100), IN login varchar(45),
                                                    IN uspassword varchar(45))
BEGIN
CALL insert_user(surname, usname, birthday, phone, address, @iduser);
CALL insert_authorization(login, uspassword, @iduser);
INSERT INTO `insurance_service`.`admin`
(`iduser`)
VALUES
(@iduser);
END;

