create
    definer = root@localhost procedure insert_contract(IN start_date date, IN end_date date, IN id_user int, IN id_service int)
BEGIN
SET @id_client = 0;
SELECT idclient
  INTO @id_client
  FROM client
 WHERE client.iduser = id_user;

INSERT INTO `insurance_service`.`contract`
(`start_date`,
`end_date`,
`idclient`,
`idservice`,
`idstatus`)
VALUES
(start_date,
end_date,
@id_client,
id_service,
1);
END;

