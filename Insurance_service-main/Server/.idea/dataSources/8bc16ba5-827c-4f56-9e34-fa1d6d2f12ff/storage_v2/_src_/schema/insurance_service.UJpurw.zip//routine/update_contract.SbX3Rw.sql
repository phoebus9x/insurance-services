create
    definer = root@localhost procedure update_contract(IN id_contract int, IN start_date date, IN end_date date,
                                                       IN id_service int)
BEGIN
  UPDATE `insurance_service`.`contract`
     SET `start_date` = start_date,
		 `end_date` = end_date,
         `idservice` = id_service
   WHERE `idcontract` = id_contract;
END;

