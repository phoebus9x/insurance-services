create
    definer = root@localhost procedure set_status(IN id_contract int, IN id_user int, IN id_status int)
BEGIN
  SET @id_agent = 0;
  SELECT idagent
    INTO @id_agent
    FROM agent
   WHERE agent.iduser = id_user;
 
  UPDATE contract
	 SET idstatus = id_status
   WHERE idcontract = id_contract;
   
  DELETE FROM reviewed_contracts
   WHERE idcontract = id_contract AND idagent = @id_agent;

  INSERT INTO `insurance_service`.`reviewed_contracts` (`idagent`, `idcontract`)
   VALUES (@id_agent, id_contract);
END;

