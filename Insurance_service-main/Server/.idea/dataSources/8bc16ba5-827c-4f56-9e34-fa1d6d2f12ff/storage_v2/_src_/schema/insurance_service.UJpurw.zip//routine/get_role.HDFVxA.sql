create
    definer = root@localhost procedure get_role(IN uslogin varchar(45), IN uspass varchar(45), OUT id_user int,
                                                OUT usrole varchar(10))
BEGIN
SET id_user = 0;
SET usrole = "";
  SELECT iduser INTO id_user FROM authorization
  WHERE `login` = uslogin AND `password` = uspass;

  SELECT COALESCE(ur, "") into usrole  
  FROM ( select "user" as ur from `client` where iduser = id_user
         union
         select "agent" as ur from `agent` where iduser = id_user
         union
         select "admin" as ur from `admin` where iduser = id_user
        ) as T;
END;

