create
    definer = root@localhost procedure update_client(IN id_user int, IN passport varchar(10), IN surname varchar(45),
                                                     IN usname varchar(45), IN birthday date, IN phone varchar(13),
                                                     IN address varchar(100))
BEGIN
UPDATE `insurance_service`.`client`
SET
`passport` = passport
WHERE `iduser` = id_user;
CALL update_user(id_user, surname, usname, birthday, phone, address);
END;

