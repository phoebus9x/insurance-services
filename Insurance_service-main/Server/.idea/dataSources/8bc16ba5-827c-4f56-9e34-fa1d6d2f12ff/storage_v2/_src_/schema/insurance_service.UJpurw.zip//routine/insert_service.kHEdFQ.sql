create
    definer = root@localhost procedure insert_service(IN sname varchar(255), IN price float, IN payout float)
BEGIN
INSERT INTO `insurance_service`.`service`
(`name`,
`price_per_month`,
`payout`)
VALUES
(sname, price, payout);
END;

