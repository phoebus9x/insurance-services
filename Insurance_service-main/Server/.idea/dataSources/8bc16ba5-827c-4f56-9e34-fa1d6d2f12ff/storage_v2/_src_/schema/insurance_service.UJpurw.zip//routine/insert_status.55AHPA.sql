create
    definer = root@localhost procedure insert_status(IN id_status int, IN status_name varchar(45))
BEGIN
INSERT INTO `insurance_service`.`status`
(`idstatus`, `status_name`)
VALUES
(id_status, status_name);
END;

