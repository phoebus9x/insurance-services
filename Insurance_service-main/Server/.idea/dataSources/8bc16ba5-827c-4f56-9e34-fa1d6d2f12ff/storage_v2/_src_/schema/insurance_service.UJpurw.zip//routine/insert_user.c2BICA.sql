create
    definer = root@localhost procedure insert_user(IN surname varchar(45), IN usname varchar(45), IN birthday date,
                                                   IN phone varchar(13), IN address varchar(100), OUT id_user int)
BEGIN
INSERT INTO `insurance_service`.`user`
(`surname`, `name`, `birthday`, `phone`, `address`)
VALUES
(surname, usname, birthday, phone, address);
SELECT last_insert_id() INTO id_user;
END;

