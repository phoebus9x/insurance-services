create definer = root@localhost trigger contract_BEFORE_UPDATE
    before UPDATE
    on contract
    for each row
BEGIN
  set new.price = f_get_price(new.start_date, new.end_date, new.idservice);
END;

