create
    definer = root@localhost procedure update_authorization(IN id_user int, IN login varchar(45), IN pass varchar(45))
BEGIN
UPDATE `insurance_service`.`authorization`
SET
`login` = login,
`password` = pass
WHERE `iduser` = id_user;
END;

