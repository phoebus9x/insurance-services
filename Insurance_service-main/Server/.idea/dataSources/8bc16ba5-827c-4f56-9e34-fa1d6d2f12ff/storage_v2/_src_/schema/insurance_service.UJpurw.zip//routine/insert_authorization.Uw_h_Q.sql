create
    definer = root@localhost procedure insert_authorization(IN login varchar(45), IN uspassword varchar(45), IN iduser int)
BEGIN
INSERT INTO `insurance_service`.`authorization`
(`login`,
`password`,
`iduser`)
VALUES
(login, uspassword, iduser);
END;

