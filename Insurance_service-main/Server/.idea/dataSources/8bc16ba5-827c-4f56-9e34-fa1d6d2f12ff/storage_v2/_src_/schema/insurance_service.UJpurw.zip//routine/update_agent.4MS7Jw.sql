create
    definer = root@localhost procedure update_agent(IN id_user int, IN employment_date date, IN surname varchar(45),
                                                    IN usname varchar(45), IN birthday date, IN phone varchar(13),
                                                    IN address varchar(100))
BEGIN
UPDATE `insurance_service`.`agent`
SET
`employment_date` = employment_date
WHERE `iduser` = id_user;
CALL update_user(id_user, surname, usname, birthday, phone, address);
END;

