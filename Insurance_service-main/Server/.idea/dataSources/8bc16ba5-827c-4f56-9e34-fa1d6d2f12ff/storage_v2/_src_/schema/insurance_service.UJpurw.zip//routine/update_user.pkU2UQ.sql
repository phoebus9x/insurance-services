create
    definer = root@localhost procedure update_user(IN id_user int, IN surname varchar(45), IN usname varchar(45),
                                                   IN birthday date, IN phone varchar(13), IN address varchar(100))
BEGIN
UPDATE `insurance_service`.`user`
SET
`surname` = surname,
`name` = usname,
`birthday` = birthday,
`phone` = phone,
`address` = address
WHERE `iduser` = id_user;
END;

