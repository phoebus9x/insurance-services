create definer = root@localhost trigger contract_BEFORE_INSERT
    before INSERT
    on contract
    for each row
BEGIN
  set new.price = f_get_price(new.start_date, new.end_date, new.idservice);
END;

