create
    definer = root@localhost function f_get_price(startDate date, endDate date, id_service int) returns float
BEGIN
  SET @price_month = 0;
  SELECT price_per_month INTO @price_month
    FROM service
   WHERE service.idservice = id_service;
  RETURN ((DATEDIFF(endDate, startDate)) * @price_month / 30);  
END;

