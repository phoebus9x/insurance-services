create
    definer = root@localhost procedure update_service(IN id_service int, IN sname varchar(255), IN ppm float, IN payout float)
BEGIN
UPDATE `insurance_service`.`service`
SET
`name` = sname,
`price_per_month` = ppm,
`payout` = payout
WHERE `idservice` = id_service;
END;

